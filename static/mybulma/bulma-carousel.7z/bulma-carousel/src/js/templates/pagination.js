export default () => {
	return `<div class="slider-pagination"></div>`;
};